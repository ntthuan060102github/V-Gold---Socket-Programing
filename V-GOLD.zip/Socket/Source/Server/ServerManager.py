from tkinter import * 
from tkinter import messagebox
from tkinter import ttk 
import tkinter as tk
import socket
import threading
from datetime import *
import json
import requests

from AnalysisRequest import *

API = "https://tygia.com/json.php?ran=0&rate=0&gold=1&bank=VIETCOM&date=now"

SIGNUP = "SIGNUP"
LOGIN = "LOGIN"
LOOKUP = "LOOKUP"
LOGOUT = "LOGOUT"
SERVER404 = "404"

HOST = '127.0.0.1'
SERVER_PORT = 65432 
FORMAT = "utf8"

accountsOnline =[]

def setInterval(func,time = 1800):
    e = threading.Event()
    if time != 1800:
        if not e.wait(time):
            func()
    else:
        while not e.wait(time):
            func()
def crawlDataFromAPI():
    lastUpdate = datetime.now()

    serverResquestAPI = requests.get(API).text
    serverResquestAPI= serverResquestAPI[2:]

    dataAPI = json.loads(serverResquestAPI)
    dataAPI['last update'] = str(lastUpdate)

    file = open('databases/dataAPI.json')
    oldData = json.load(file)
    oldData.append(dataAPI)
    file.close()

    with open('databases/dataAPI.json', 'w') as w:
        json.dump(oldData, w)
    w.close()
def getDataFromAPI():
    with open("databases/dataAPI.json", "r", encoding=FORMAT) as file:
        data = json.load(file)
    file.close()
    lastUpdate = datetime.fromisoformat(data[len(data)-1]['last update'])
    now = datetime.now()
    countdown = now - lastUpdate
    if countdown.seconds > 1800:
        crawlDataFromAPI()
    else:
        setInterval(crawlDataFromAPI, 1800 - countdown.seconds)
    setInterval(crawlDataFromAPI)
def typeOfGold():
    file = open('databases/dataAPI.json')
    data = json.load(file)
    goldList = data["golds"][0]["value"]
    typeGolds = []
    for t in goldList:
        try:
            typeGolds.index(t["type"])
        except:
            typeGolds.append(t["type"])
    return typeGolds
def serverRunning():
    try:
        while True:
            connection, address = server.accept()
            clientThread = threading.Thread(target=handleClient,args=(connection,address))
            serverFrame.insertNewStatus(("IP: "+str(address[0]) + "  -  Port: "+str(address[1])),
                                        "Client " + str(address) +" đã kết nối tới server.",len(managerTable.get_children())+1)                            
            clientThread.start()
    except:
        pass
    finally:
        server.close()

def handleClient(connection, address):
    while True:
        option = connection.recv(1024).decode(FORMAT)

        if option == LOGIN:
            clientLogIn(connection, address)
        elif option==SIGNUP:
            clientSignUp(connection, address)
        elif option == LOGOUT:
            clientLogOut(connection, address,connection.recv(1024).decode(FORMAT) )
        elif option == LOOKUP:
            clientLookUp(connection, address)
def accountIsValid(account, password):
    file = open('databases/clientAccount.json')
    data = json.load(file)
    file.close() 
    for accOnl in accountsOnline:
        if account == accOnl:
            return 3
    for accountInf in data:
        if(accountInf["account"] == account):
            if(accountInf["password"] == password):
                file.close()
                return 1
            break
    return 2
def newAccountIsValid(account, password):
    file = open('databases/clientAccount.json')
    data = json.load(file)
    for accountInf in data:
        if(accountInf["account"] == account):
            file.close()
            return 2
    file.close()
    return 1
def clientLogIn(sck, address):
    account = sck.recv(1024).decode(FORMAT)
    sck.sendall(account.encode(FORMAT))
    password = sck.recv(1024).decode(FORMAT)
    accepted = accountIsValid(account, password)
    sck.sendall(str(accepted).encode(FORMAT))
    if accepted == 1:
        accountsOnline.append(account)
        serverFrame.insertNewStatus(("IP: "+str(address[0]) + "  -  Port: "+str(address[1])), "Client đã đăng nhập với tài khoản: "+ account,len(managerTable.get_children())+1)
def clientSignUp(sck, address):
    account = sck.recv(1024).decode(FORMAT)
    sck.sendall(account.encode(FORMAT))
    password = sck.recv(1024).decode(FORMAT)
    accepted = newAccountIsValid(account, password)
    sck.sendall(str(accepted).encode(FORMAT))
    if accepted == 1:
        newAccount = {"account": account, "password": password}
        file = open('databases/clientAccount.json')
        data = json.load(file)
        data.append(newAccount)
        file.close()
        with open('databases/clientAccount.json', 'w') as w:
            json.dump(data, w)
        w.close()
        serverFrame.insertNewStatus(("IP: "+str(address[0]) + "  -  Port: "+str(address[1])), "Client đã đăng ký tài khoản mới với accoutn: "+account,len(managerTable.get_children())+1)
def clientLogOut(connection, address,account):
    serverFrame.insertNewStatus(("IP: "+str(address[0]) + "  -  Port: "+str(address[1])), "Client "+ str(address) +" đã đăng xuất!",len(managerTable.get_children())+1)
    accountsOnline.remove(account)
    connection.close()
def clientLookUp(sck, address):
    requestLookUp = sck.recv(1024).decode(FORMAT)

    sck.sendall(requestLookUp.encode(FORMAT))
    serverFrame.insertNewStatus(("IP: "+str(address[0]) + "  -  Port: "+str(address[1])), "Client gửi yêu cầu tìm kiếm thông tin vàng!",len(managerTable.get_children())+1)
    result = getDataFromRequest(requestLookUp)
    if result == [] or result == 0:
        sck.sendall("DATA: 0".encode(FORMAT))
    else: 
        sck.sendall("DATA: 1".encode(FORMAT))
        sendData(result,sck)
def sendData(result,sck):
    lenData = len(result)
    sck.sendall(str(lenData).encode(FORMAT))
    sck.recv(1024)
    for eleResult in result:
        if eleResult["buy"] != '':
            sck.sendall(str(eleResult["buy"]).encode(FORMAT))
            sck.recv(1024)
        else:
            sck.sendall("Không có thông tin.".encode(FORMAT))
            sck.recv(1024)

        if eleResult["sell"] != '':
            sck.sendall(str(eleResult["sell"]).encode(FORMAT))
            sck.recv(1024)
        else:
            sck.sendall("Không có thông tin.".encode(FORMAT))
            sck.recv(1024)

        if eleResult["company"] != '':
            sck.sendall(str(eleResult["company"]).encode(FORMAT))
            sck.recv(1024)
        else:
            sck.sendall("Không có thông tin.".encode(FORMAT))
            sck.recv(1024)

        if eleResult["brand"] != '':       
            sck.sendall(str(eleResult["brand"]).encode(FORMAT))
            sck.recv(1024)
        else:
            sck.sendall("Không có thông tin.".encode(FORMAT))
            sck.recv(1024)

        if eleResult["id"] != '':        
            sck.sendall(str(eleResult["id"]).encode(FORMAT))
            sck.recv(1024)
        else:
            sck.sendall("Không có thông tin.".encode(FORMAT))
            sck.recv(1024)

        if eleResult["type"] != '':
            sck.sendall(str(eleResult["type"]).encode(FORMAT))
            sck.recv(1024)
        else:
            sck.sendall("Không có thông tin.".encode(FORMAT))
            sck.recv(1024)

class App(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        self.protocol("WM_DELETE_WINDOW", self.onClosing)
        container = tk.Frame(self)
        container.pack(side="top", fill = "both", expand = True)
        
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (serverFrame, serverInit):
            frame = F(container, self)
            self.frames[F] = frame 
            frame.grid(row=0, column=0, sticky="nsew")
        self.showFrame(serverFrame)
    def showFrame(self, container):
        frame = self.frames[container]
        if container == serverFrame:
            self.title("Server")
        self.resizable(width=False, height=False)
        frame.tkraise()
    def devTeamBtn(self):
        self.devTeamWindown = tk.Toplevel(width=437,height=618)
        self.devTeamWindown.title("V-Gold Developer Team")
        self.devTeamWindown.resizable(width=False, height=False)
        self.backgroundImg = PhotoImage(file="resource/DEVELOPER TEAM.png")
        self.bg = Label(self.devTeamWindown,image = self.backgroundImg)
        self.bg.place(x=0,y=0)
        self.devTeamWindown.iconbitmap('resource/iconICO.ico')
    def onClosing(self):
        if messagebox.askokcancel("Thoát!", "Bạn muốn thoát chương trình?"):
            server.close()
            self.destroy()
            try:
                # server.sendall("SERVER OFFLINE".encode(FORMAT))
                pass
            except:
                pass
class serverFrame(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        columns = ('.NO', 'Date', 'IP address', 'Detail')
        global managerTable
        managerTable = ttk.Treeview(self, columns=columns,show='headings', height=20)

        managerTable.heading('.NO', text='.NO')
        managerTable.heading('Date', text='Date')
        managerTable.heading('IP address', text='IP address')
        managerTable.heading('Detail', text='Detail')

        managerTable.grid(row=0, column=0, sticky='nsew')

        scrollbar = ttk.Scrollbar(self, orient=VERTICAL, command=managerTable.yview)
        managerTable.configure(yscroll=scrollbar.set)
        scrollbar.grid(row=0, column=1, sticky='ns')

        self.infTeamImg = PhotoImage(file="resource/Button_Info.png")
        infTeamBtn = Button(self, image = self.infTeamImg,bd=0,bg="#ffffff", command =controller.devTeamBtn)
        infTeamBtn.place(x = 777, y = 4)

        # managerTable.configure("Treeview", background="#383838", foreground="white", fieldbackground="red")

    def insertNewStatus(address, detail, orderNum):
        now = datetime.now()
        newClient =[orderNum, str(now), address , detail]
        managerTable.insert('', END, values=newClient)

class serverInit(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        pass

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST,SERVER_PORT))
server.listen()

app = App()
crawlDataFromAPI()
thread = threading.Thread(target=serverRunning, daemon = True)
thread.start() 
threadAPI = threading.Thread(target=getDataFromAPI, daemon = True)
threadAPI.start()
app.mainloop()