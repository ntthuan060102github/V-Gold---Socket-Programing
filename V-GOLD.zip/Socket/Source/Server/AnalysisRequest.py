from datetime import *
import json

s1 = u'ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝàáâãèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯưẠạẢảẤấẦầẨẩẪẫẬậẮắẰằẲẳẴẵẶặẸẹẺẻẼẽẾếỀềỂểỄễỆệỈỉỊịỌọỎỏỐốỒồỔổỖỗỘộỚớỜờỞởỠỡỢợỤụỦủỨứỪừỬửỮữỰựỲỳỴỵỶỷỸỹ'
s0 = u'AAAAEEEIIOOOOUUYaaaaeeeiioooouuyAaDdIiUuOoUuAaAaAaAaAaAaAaAaAaAaAaAaEeEeEeEeEeEeEeEeIiIiOoOoOoOoOoOoOoOoOoOoOoOoUuUuUuUuUuUuUuYyYyYyYy'
def removeAccents(input_str):
	s = ''
	for c in input_str:
		if c in s1:
			s += s0[s1.index(c)]
		else:
			s += c
	return s
# xử lý sự trùng khớp về mặt từ khóa, ưu tiền từ khóa mang phạm vi rộng hơn bao trùm các từ khóa con
def duplicateResults(reqKeyWords,reqKey):
    for parKey in reqKeyWords:
        count = 0
        for childEle in reqKey:
            if parKey.count(childEle):
                count+=1
        if(count == len(reqKey)):
            return False
    return True
def typeOfGold(idx):
    file = open('databases/dataAPI.json')
    data = json.load(file)
    goldList = data[idx]["golds"][0]["value"]
    typeGolds = []
    for t in goldList:
        try:
            typeGolds.index(removeAccents(t["type"].casefold()))
        except:
            typeGolds.append(removeAccents(t["type"].casefold()))
    return typeGolds
# lấy ra vị trí của data ứng với ngày mà user muốn tìm kiếm, trả về vị trí hoặc -1 ứng với không tồn tại
def getIndexDataOfDate(date):
    date = date[::-1]
    time = '-'.join(date)
    file = open('databases/dataAPI.json')
    allData = json.load(file)[::-1]
    idxData=len(allData)-1
    for data in allData:
        if data["last update"].rfind(time) != -1:
            return idxData
        idxData-=1
    return -1
# xử lý request lấy ra dữ dữ liêu về thời gian.
# trả về thời gian nếu có hoặc -1 và request sau khi loại bỏ dữ liệu về thời gian
def getTimeFromRequest(req):
    noAccentsReq = removeAccents(req.casefold())
    reqKeyWords = noAccentsReq.split()
    reqKeyWordsRev = noAccentsReq.split()[::-1]
    for reqKeyWord in reqKeyWordsRev:
        # Xử lý ngày tháng năm dạng d/m/y
        if reqKeyWord.count("/") == 2 or reqKeyWord.count("-") == 2 or reqKeyWord.count(".") == 2:
            if reqKeyWord.count("/") == 2:
                time = reqKeyWord.split("/")
                noAccentsReq = noAccentsReq.replace("/".join(time),"")
            elif reqKeyWord.count(".") == 2:
                time = reqKeyWord.split(".")
                noAccentsReq = noAccentsReq.replace(".".join(time),"")
            else:
                time = reqKeyWord.split("-")
                noAccentsReq = noAccentsReq.replace("-".join(time),"")
            if 1<=int(time[0])<=31 and 1<=int(time[1])<=12 and int(time[2])>=2000:
                return time, noAccentsReq
            else: return -1,noAccentsReq
        # Xử lý ngày tháng năm dạng d/m m/y
        if reqKeyWord.count("/") == 1 or reqKeyWord.count("-") == 1 or reqKeyWord.count(".") == 1:
            if reqKeyWord.count("/") == 1:
                time = reqKeyWord.split("/")
                noAccentsReq = noAccentsReq.replace("/".join(time),"")
            elif reqKeyWord.count(".") == 1:
                time = reqKeyWord.split(".")
                noAccentsReq = noAccentsReq.replace(".".join(time),"")
            else:
                time = reqKeyWord.split("-")
                noAccentsReq = noAccentsReq.replace("-".join(time),"")
            if (1<=int(time[0])<=31 and 1<=int(time[1])<=12) or (1<=int(time[0])<=12 and int(time[1])>= 2000):
                return time, noAccentsReq
            else: return -1,noAccentsReq
        # Xử lý ngày tháng năm dạng ngôn ngữ tự nhiên (vie)
    time = []
    count =0
    for reqKeyWord in reqKeyWords:
        try:
            if reqKeyWord == "ngay" and int(reqKeyWords[reqKeyWords.index("ngay")+1]):
                time.append(reqKeyWords[reqKeyWords.index("ngay")+1])
                count+=1
            if reqKeyWord == "thang" and int(reqKeyWords[reqKeyWords.index("thang")+1]):
                count+=1
                time.append(reqKeyWords[reqKeyWords.index("thang")+1])
            if reqKeyWord == "nam" and int(reqKeyWords[reqKeyWords.index("nam")+1]):
                count+=1
                time.append(reqKeyWords[reqKeyWords.index("nam")+1])
        except:
            return -1,noAccentsReq
        
    if len(time) != 0:
        if count ==2 and (1<=int(time[0])<=31 and 1<=int(time[1])<=12) or (1<=int(time[0])<=12 and int(time[1])>= 2000):
            if 1<=int(time[0])<=31 and 1<=int(time[1])<=12:
                dateStr = "ngay " + time[0] + " thang " + time[1]
            else:
                dateStr = "thang " + time[0] + " nam " + time[1]
            return time, noAccentsReq.replace(dateStr,"")
        elif count ==3 and  (1<=int(time[0])<=31 and 1<=int(time[1])<=12 and int(time[2])>=2000):
            dateStr = "ngay " + time[0] + " thang " + time[1] +" nam " + time[2]
            return time, noAccentsReq.replace(dateStr,"")
        else: return -1,noAccentsReq
    else: return -1,noAccentsReq
# phân tích request và trả về list các từ khóa hoặc 1 ứng với tất cả dữ liệu
def analysisLookUpRequest(req,dataIdx):
    noAccentsReq = removeAccents(req.casefold())
    reqKeyWords = []
    time, noAccentsReq = getTimeFromRequest(noAccentsReq)
    # if time ==-1:
    #     if noAccentsReq.rfind("vang") != -1:
    #         return 1
    #     else: return 0
    # idxData = getIndexDataOfDate(time)
    # if idxData == -1:
    #     return 0
    typeGold = typeOfGold(dataIdx)

    for ty in typeGold:
        tyList = ty.split()
        reqKeyWord = []
        for t in tyList:
            if noAccentsReq.count(t):
                reqKeyWord.append(t)
        if(len(reqKeyWord)!=0):
            if((not reqKeyWords.count(reqKeyWord)) and duplicateResults(reqKeyWords,reqKeyWord) and reqKeyWord != ["vang"]):
                reqKeyWords.append(reqKeyWord)
    reqKeys = []
    for reqKeyWord in reqKeyWords:
        reqKey =""
        for key in reqKeyWord:
            reqKey += " "+key
        reqKeys.append(reqKey.strip())
    if(len(reqKeys) == 0 and noAccentsReq.rfind('vang') != -1):
        return 1
    return reqKeys
def getDataFromRequest(req):
    time, newReq = getTimeFromRequest(req)
    file = open('databases/dataAPI.json')
    allData = json.load(file)
    if time!=-1:
        idx = getIndexDataOfDate(time)
    else:
        idx = len(allData)-1
    if idx == -1: return 0
    reqKeys = analysisLookUpRequest(req,idx)
    dataList = allData[idx]["golds"][0]["value"]

    if reqKeys == 1:
        return dataList

    reqData =[]
    for dataEle in dataList:
        for reqKey in reqKeys:
            if (removeAccents(dataEle["type"].casefold())).find(reqKey) != -1:
                reqData.append(dataEle)
                break
    file.close()
    return reqData
# print(getDataFromRequest("9999 ngay 25 thang 12"))