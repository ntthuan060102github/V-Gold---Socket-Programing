from tkinter import * 
from tkinter import messagebox
import socket
from tkinter import ttk 
import tkinter as tk

SIGNUP = "SIGNUP"
LOGIN = "LOGIN"
LOOKUP = "LOOKUP"
LOGOUT = "LOGOUT"
SERVER404 = "404"

HOST = '127.0.0.1'
SERVER_PORT = 65432 
FORMAT = "utf8"

class App(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        self.protocol("WM_DELETE_WINDOW", self.onClosing)
        container = tk.Frame(self)
        container.pack(side="top", fill = "both", expand = True)
        
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (loginFrame,registerFrame ,lookUpFrame,server404Frame,VGoldFrame):
            frame = F(container, self)
            self.frames[F] = frame 
            frame.grid(row=0, column=0, sticky="nsew")
        self.showFrame(VGoldFrame)
    def showFrame(self, container):
        frame = self.frames[container]
        self.title("V-GOLD")
        if container == loginFrame:
            self.geometry("1000x416")
        elif container == registerFrame:
            self.geometry("345x520")
        elif container == lookUpFrame:
            self.geometry("1242x670")
        elif container == server404Frame:
            self.geometry("1216x682")
            self.title("V-GOLD 404")
        else:
            self.geometry("400x550")
        self.resizable(width=False, height=False)
        self.iconbitmap('resource/iconICO.ico')
        frame.tkraise()
    def clickNewAccountBtn(self):
        self.showFrame(registerFrame)
    def newAccountIsValid(self,accountInfo):
        if (accountInfo[0] == "" or accountInfo[0].find(" ") != -1) and (accountInfo[1] == "" or accountInfo[1].find(" ") != -1):
            return 0
        elif (accountInfo[0] == "" or accountInfo[0].find(" ") != -1):
            return 1
        elif (accountInfo[1] == "" or accountInfo[1].find(" ") != -1):
            return 2
        elif (accountInfo[2] == "" or accountInfo[2].find(" ") != -1 or accountInfo[2] != accountInfo[1]):
            return 3
        else: return 4 
    def clickCreateNewAccountBtn(self,curFrame, sck):
        account = accountRegisterBox.get()
        password = passwordRegisterBox.get()
        repassword = repasswordRegisterBox.get()
        accountInf =[account, password, repassword]

        isValid = self.newAccountIsValid(accountInf)
        
        if isValid == 0:
            tk.messagebox.showerror('Lỗi','Tài khoản và mật khẩu không hợp lệ!')
        elif isValid == 1:
            tk.messagebox.showerror('Lỗi','Tài khoản không hợp lệ!')
        elif isValid == 2:
            tk.messagebox.showerror('Lỗi','Mật khẩu không hợp lệ!')
        elif isValid == 3:
            tk.messagebox.showerror('Lỗi','Nhập lại mật khẩu chưa chính xác!')
        else: 
            try:
                option = SIGNUP
                sck.sendall(option.encode(FORMAT))
                sck.sendall(account.encode(FORMAT))
                sck.recv(1024)
                sck.sendall(password.encode(FORMAT))
                accepted = sck.recv(1024).decode(FORMAT)
            except:
                self.showFrame(server404Frame)

            if accepted == "1":
                tk.messagebox.showinfo('Thông báo!','Tài khoản đăng ký thành công!')

                accountRegisterBox.delete(0,"end")
                accountRegisterBox.insert(0,"")
                passwordRegisterBox.delete(0,"end")
                passwordRegisterBox.insert(0,"")
                repasswordRegisterBox.delete(0,"end")
                repasswordRegisterBox.insert(0,"")
                
                self.showFrame(loginFrame)
            else:
                tk.messagebox.showinfo('Thông báo!','Tài khoản đã tồn tại.\nVui lòng thay đổi thông tin đăng ký!')
    def clickBackLoginFrame(self):
        self.showFrame(loginFrame)
    def clickLoginBtn(self,curFrame, sck):
        account = accountLoginBox.get()
        password = passwordLoginBox.get()

        option = LOGIN
        if account == "" or password == "":
            tk.messagebox.showerror("Lỗi!",'Vui lòng kiểm tra lại thông tin đăng nhập!')
        else:
            try:
                sck.sendall(option.encode(FORMAT))
                sck.sendall(account.encode(FORMAT))
                sck.recv(1024)
                sck.sendall(password.encode(FORMAT))

                accepted = sck.recv(1024).decode(FORMAT)
            except:
                self.showFrame(server404Frame)
        if(accepted =="3"):
            tk.messagebox.showerror("Lỗi!",'Tài khoản này hiện đang được đăng nhập tại nơi khác!')
        elif(accepted =="1"):
            self.showFrame(lookUpFrame)
        else:
            tk.messagebox.showerror("Lỗi!",'Vui lòng kiểm tra lại thông tin đăng nhập!')
    def onClosing(self):
        if messagebox.askokcancel("Thoát!", "Bạn muốn thoát chương trình?"):
            try:
                option = LOGOUT
                client.sendall(option.encode(FORMAT))
                client.sendall(accountLoginBox.get().encode(FORMAT))
            except:
                pass
            finally:
                client.close()
                self.destroy()
    def clickConnectBtn(self):
        server_address = (serverIPBox.get(), SERVER_PORT)
        try:
            client.connect(server_address)
            self.showFrame(loginFrame)
        except:
            self.showFrame(server404Frame)
            client.close()
    def clickSeachBtn(self,lookUpBox, sck): 
        requestLookUp = lookUpBox.get()
        if requestLookUp == "":
            tk.messagebox.showinfo('Thông báo!','Không tìm thấy dữ liệu hợp lệ!')
        else:
            option = LOOKUP
            try:
                sck.sendall(option.encode(FORMAT))

                sck.sendall(str(requestLookUp).encode(FORMAT))
                sck.recv(1024)
            except:
                self.showFrame(server404Frame)

            resultKey = sck.recv(1024).decode(FORMAT)
            if resultKey == "DATA: 1":
                result =self.receiveData(sck)
                lookUpFrame.showResult(lookUpFrame,result)
            else:
                tk.messagebox.showinfo('Thông báo!','Không tìm thấy kết quả hợp lệ!')
    def receiveData(self,sck):
        lenData = int((sck.recv(1024)).decode(FORMAT))
        sck.sendall("1".encode(FORMAT))
        count = 0
        result =[]
        while count != lenData:
            ele = {}
            
            tempReult = sck.recv(1024).decode(FORMAT)
            ele["buy"] = tempReult
            sck.sendall("1".encode(FORMAT))

            tempReult = sck.recv(1024).decode(FORMAT)
            ele["sell"] = tempReult
            sck.sendall("1".encode(FORMAT))

            tempReult = sck.recv(1024).decode(FORMAT)
            ele["company"] = tempReult
            sck.sendall("1".encode(FORMAT))

            tempReult = sck.recv(1024).decode(FORMAT)
            ele["brand"] = tempReult
            sck.sendall("1".encode(FORMAT))

            tempReult = sck.recv(1024).decode(FORMAT)
            ele["id"] = tempReult
            sck.sendall("1".encode(FORMAT))

            tempReult = sck.recv(1024).decode(FORMAT)
            ele["type"] = tempReult
            sck.sendall("1".encode(FORMAT))

            result.append(ele)
            count+=1
        return result
    def clickVisibilityBtn(self,entry,btn):
        if entry["show"] == "*":
            entry["show"]=""
            self.unVisibilityImg = PhotoImage(file="resource/Visibility_On.png")
            btn["image"] = self.unVisibilityImg
        else:
            entry["show"]="*"
            self.visibilityImg = PhotoImage(file="resource/Visibility_Off.png")
            btn["image"] = self.visibilityImg
    def clickVisibilityBtn2(self,entry,btn):
        if entry["show"] == "*":
            entry["show"]=""
            self.unVisibilityImg = PhotoImage(file="resource/Visibility_On2.png")
            btn["image"] = self.unVisibilityImg
        else:
            entry["show"]="*"
            self.visibilityImg = PhotoImage(file="resource/Visibility_Off2.png")
            btn["image"] = self.visibilityImg
    def devTeamBtn(self):
        self.devTeamWindown = tk.Toplevel(self,width=437,height=618)
        self.devTeamWindown.title("V-Gold Developer Team")
        self.devTeamWindown.resizable(width=False, height=False)
        self.backgroundImg = PhotoImage(file="resource/DEVELOPER TEAM.png")
        self.bg = Label(self.devTeamWindown,image = self.backgroundImg)
        self.bg.place(x=0,y=0)
        self.devTeamWindown.iconbitmap('resource/iconICO.ico')
class loginFrame(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.backgroundImg = PhotoImage(file="resource/bgLogin.png")
        self.background = Label( self, image = self.backgroundImg)
        self.background.place(x = 0,y = 0)


        accountTxtLabel = Label(self, text="Tài khoản", font=("Microsoft Sans Serif",12), bg='white')
        accountTxtLabel.place(x = 750, y = 165)

        passwordTxtLabel = Label(self, text="Mật khẩu", font=("Microsoft Sans Serif",12), bg='white')
        passwordTxtLabel.place(x = 752, y = 240)

        global accountLoginBox, passwordLoginBox
        accountLoginBox = Entry(self,bd=0, font=("Microsoft Sans Serif",11))
        accountLoginBox.place(x = 640, y = 190, width = 300, height=30)

        passwordLoginBox = Entry(self,bd=0, font=("Microsoft Sans Serif",11), show ="*")
        passwordLoginBox.place(x = 640, y = 265, width = 300, height=30)

        newAccountBtn = Button(self, text="Bạn chưa có tài khoản?", bd=0, bg="white",font=("Microsoft Sans Serif",8), fg="#25313f", command=controller.clickNewAccountBtn)
        newAccountBtn.place(x = 640, y = 300)

        self.lineInputBoxImg = PhotoImage(file="resource/Line1.png")
        self.lineInputBox1 = Label( self, image = self.lineInputBoxImg)
        self.lineInputBox1.place(x = 638, y = 215)

        self.lineInputBox2 = Label( self, image = self.lineInputBoxImg)
        self.lineInputBox2.place(x = 638, y = 290)

        self.submitBtnImg = PhotoImage(file="resource/Button_LoginBtn.png")
        self.submitBtn = Button(self,image=self.submitBtnImg,bg="#ffffff", bd=0, command = lambda:controller.clickLoginBtn(self, client))
        self.submitBtn.place(x = 640, y = 330)

        self.visibilityImg = PhotoImage(file="resource/Visibility_Off.png")
        self.visibilityBtn = Button(self, image = self.visibilityImg,bd=0,bg="#ffffff", command = lambda:controller.clickVisibilityBtn(passwordLoginBox,self.visibilityBtn))
        self.visibilityBtn.place(x = 910, y = 265)

        self.infTeamImg = PhotoImage(file="resource/Button_Info.png")
        self.infTeamBtn = Button(self, image = self.infTeamImg,bd=0,bg="#ffffff", command =controller.devTeamBtn)
        self.infTeamBtn.place(x = 970, y = 390)
class registerFrame(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.backgroundImg = PhotoImage(file="resource/SignUp.png")
        self.background = Label( self, image = self.backgroundImg)
        self.background.place(x = 0,y = 0)

        accountTxtLabel = Label(self, text="Tài khoản", font=("Microsoft Sans Serif",8))
        accountTxtLabel.place(x = 40, y = 302)

        passwordTxtLabel = Label(self, text="Mật khẩu", font=("Microsoft Sans Serif",8))
        passwordTxtLabel.place(x = 40, y = 342)

        repasswordTxtLabel = Label(self, text="Nhập lại mật khẩu", font=("Microsoft Sans Serif",8))
        repasswordTxtLabel.place(x = 40, y = 382)

        global accountRegisterBox, passwordRegisterBox, repasswordRegisterBox
        accountRegisterBox = Entry(self, width = 27, bd=0)
        accountRegisterBox.place(x = 140, y = 300)

        passwordRegisterBox = Entry(self, width = 27, bd=0, show ="*")
        passwordRegisterBox.place(x = 140, y = 340)

        repasswordRegisterBox = Entry(self, width = 27, bd=0, show ="*")
        repasswordRegisterBox.place(x = 140, y = 380)

        self.lineInputBoxImg = PhotoImage(file="resource/Line.png")
        self.lineInputBox1 = Label( self, image = self.lineInputBoxImg)
        self.lineInputBox1.place(x = 138, y = 317)

        self.lineInputBox2 = Label( self, image = self.lineInputBoxImg)
        self.lineInputBox2.place(x = 138, y = 357)

        self.lineInputBox3 = Label( self, image = self.lineInputBoxImg)
        self.lineInputBox3.place(x = 138, y = 397)

        self.submitBtnImg = PhotoImage(file="resource/Button_CreateAcc.png")
        self.submitBtn = Button(self,image=self.submitBtnImg, bd=0,bg="#ffffff", command=lambda:controller.clickCreateNewAccountBtn(self, client))
        self.submitBtn.place(x = 30, y = 440)

        self.backBtnImg = PhotoImage(file="resource/Button_BackBtn.png")
        self.backBtn = Button(self,image=self.backBtnImg, bd=0,bg="#ffffff", command = controller.clickBackLoginFrame)
        self.backBtn.place(x = 30, y = 475)

        self.visibilityImg = PhotoImage(file="resource/Visibility_Off2.png")
        self.visibilityBtn1 = Button(self, image = self.visibilityImg,bd=0,bg="#ffffff", command = lambda:controller.clickVisibilityBtn2(passwordRegisterBox,self.visibilityBtn1))
        self.visibilityBtn1.place(x = 280, y = 342)

        self.visibilityBtn2 = Button(self, image = self.visibilityImg,bd=0,bg="#ffffff", command = lambda:controller.clickVisibilityBtn2(repasswordRegisterBox,self.visibilityBtn2))
        self.visibilityBtn2.place(x = 280, y = 382)
        
        self.infTeamImg = PhotoImage(file="resource/Button_Info1.png")
        self.infTeamBtn = Button(self, image = self.infTeamImg,bd=0,activebackground="#5b6e97",bg="#5b6e97", command =controller.devTeamBtn)
        self.infTeamBtn.place(x = 320, y = 10)

        ### Error(fixing, please waiting...): Lỗi click 1 nút visib và click nút còn lại thì nút đầu mất icon .
class lookUpFrame(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.backgroundImg = PhotoImage(file="resource/Client_Home.png")
        self.background = Label( self, image = self.backgroundImg)
        self.background.place(x = 0,y = 0)

        lookUpBox = Entry(self,bd=0, bg="#e3e3e3", font=("Microsoft Sans Serif",12))
        lookUpBox.place(x = 70,y = 80, width =1050, height =39)

        self.searchBtnImg = PhotoImage(file="resource/searchBtn.png")
        self.searchBtn = Button(self,image=self.searchBtnImg, bd=0, bg="#e3e3e3", command =lambda:controller.clickSeachBtn(lookUpBox,client))
        self.searchBtn.place(x = 1150, y = 88)

        columns = ('ID', 'TYPE', 'BUY', 'SELL','COMPANY','BRAND')
        global resultTable
        resultTable = ttk.Treeview(self, columns=columns,show='headings', height=20)

        resultTable.heading('ID', text='ID')
        resultTable.heading('TYPE', text='TYPE')
        resultTable.heading('BUY', text='BUY')
        resultTable.heading('SELL', text='SELL')
        resultTable.heading('COMPANY', text='COMPANY')
        resultTable.heading('BRAND', text='BRAND')

        resultTable.grid(row = 0, column = 0, padx=[20,0], pady=150,sticky='nsew',ipady = 37)

        scrollbar = ttk.Scrollbar(self, orient=VERTICAL, command=resultTable.yview)
        resultTable.configure(yscroll=scrollbar.set)
        scrollbar.grid(row = 0, column=1, sticky='ns',pady=150)

        self.infTeamImg = PhotoImage(file="resource/Button_Info.png")
        self.infTeamBtn = Button(self, image = self.infTeamImg,bd=0,bg="#ffffff", command =controller.devTeamBtn)
        self.infTeamBtn.place(x = 1212, y = 10)
    def showResult(self, results):
        items = resultTable.get_children()
        for item in items:
            resultTable.delete(item)
        for resultDict in results:
            result = [resultDict["id"],resultDict["type"],resultDict["buy"],resultDict["sell"],resultDict["company"],resultDict["brand"]]
            resultTable.insert('', END, values=result)
class server404Frame(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.backgroundImg = PhotoImage(file="resource/404.png")
        self.background = Label( self, image = self.backgroundImg)
        self.background.place(x = 0,y = 0)

        self.infTeamImg = PhotoImage(file="resource/Button_Info.png")
        self.infTeamBtn = Button(self, image = self.infTeamImg,bd=0,bg="#ffffff", command =controller.devTeamBtn)
        self.infTeamBtn.place(x = 1190, y = 655)
class VGoldFrame(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.backgroundImg = PhotoImage(file="resource/V-Gold bg.png")
        self.background = Label( self, image = self.backgroundImg)
        self.background.place(x = 0,y = 0)
        
        global serverIPBox
        serverIPBox = Entry(self,bd=0, font=("Microsoft Sans Serif",12),justify="center")
        serverIPBox.place(x = 50, y = 420, width = 300, height=30)

        self.lineInputBoxImg = PhotoImage(file="resource/Line1.png")
        self.lineInputBox1 = Label( self, image = self.lineInputBoxImg)
        self.lineInputBox1.place(x = 50, y =450)

        self.connectBtnImg = PhotoImage(file="resource/Button_ConnectBtn.png")
        self.connectBtn = Button(self,image=self.connectBtnImg,bg="#ffffff", bd=0, command = controller.clickConnectBtn)
        self.connectBtn.place(x = 50, y = 470)

        self.infTeamImg = PhotoImage(file="resource/Button_Info.png")
        self.infTeamBtn = Button(self, image = self.infTeamImg,bd=0,bg="#ffffff", command =controller.devTeamBtn)
        self.infTeamBtn.place(x = 370, y = 520)

        # frameCnt = 30
        # frames = [PhotoImage(file='resource/loading1.gif',height =45,format = 'gif -index %i' %(i)) for i in range(frameCnt)]

        # def update(ind):
        #     frame = frames[ind]
        #     ind += 1
        #     if ind == frameCnt:
        #         ind = 0
        #     label.configure(image=frame)
        #     self.after(100, update, ind)
        # label = Label(self,bd=0)
        # label.pack(side= "bottom")
        # def load():
        #     self.after(0, update, 0)
        # loadT = threading.Thread(target=load, daemon = True)
        # loadT.start()
app = App()
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
app.mainloop()

